/* try the different advanced selection calls here */

