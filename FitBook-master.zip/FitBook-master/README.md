# Fit-Game-Website
1. These are the codes regarding my project of making a fit game in which I am able to integrate the Google Fit App to a website.
2. This project is related with web development.
3. This project will be able to show your all information regarding your steps taken at different times in a day in a table which has been referenced from fitbit.com (iffibitmaster.com)
4. Now I want to do more advancements in the project where on the total steps a person has walked , I can give them ranks.
5. This can then become a proper FITBOOK.

![Khufiyapa](https://raw.githubusercontent.com/suprgyabhushan/FitBook/master/index1.jpeg)
