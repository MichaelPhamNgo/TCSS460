<?php
    define('APP_NAME', "GoogleFeedBit");
    define('APP_SERVER', "localhost/fit.com/public_html/main.html");
    define('APP_TITLE', "FIT GAME");
    define('APP_DESC', '');
    define('APP_ANALYTICS', 'UA-13184829-x');
?>
