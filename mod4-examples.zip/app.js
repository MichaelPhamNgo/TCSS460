// *******************************************
// mod4-examples source code:
// random number generator REST Service
// *******************************************

// import required module
var express = require("express");
var app = express();


// define a route using a callback function that will be invoked
// when the user makes a HTTP request to the root of the folder (URL)
// display some information about the REST Service
app.get('/', function (req, res) {
    res.status(200);
    res.send("<h1>This REST service will randomly generate numbers.</h1>");
    console.log("a request has been processed in / (root) ");
});

// randomize a number up to a max of 1000
app.get('/random', function(req, res) {
    const result = Math.floor(Math.random() * 1000);
    console.log("/random   request is made...");
    res.json({ "result" : result});
});

// randomize a number based on an upper limit
// http://some_address/random/{value}
app.get('/random/:max', function(req, res) {
    const max = req.params.max;
    if (isNaN(max))
    {
        res.status(400);
        res.json({error: "bad request"});
        return ;
    }
    const result = Math.floor(Math.random() * Math.floor(req.params.max));
    console.log("/random/max   request is made...");
    res.json({ "result" : result}); 
})

// randomize a number based on upper and lower limits
// http://some_address/random/{max}/{min}
app.get('/random/:min/:max', function(req, res) {
    const max = parseInt(req.params.max);
    const min = parseInt(req.params.min);
    if (isNaN(max) || isNaN(min))
    {
        res.status(400);
        res.json({error: "bad request"});
        return ;
    }
    const result = Math.floor(Math.random() * (max - min) + min);
    console.log("/random/min/max   request is made...");
    res.json({ "result" : result}); 
});

// perform a checkfor custom header attributes
app.get('/check', function (req, res) {
    var checheader = '';
    checkHeader = req.get("whoami");
    console.log(checheader);

    if (checkHeader === undefined || checkHeader === "") {
        res.status(403);
        res.json({error : "you are not allowed to execute this request"});
        return;
    }

    res.set("authorized", "yes, you are authorized: " + checkHeader);
    res.json({ success: checkHeader + " you are allowed to execute this request"});
});



// enable a port to listen to incoming HTTP requests
app.listen(3000, function () {
    console.log("API version 1.0.0 is running on port 3000");
});